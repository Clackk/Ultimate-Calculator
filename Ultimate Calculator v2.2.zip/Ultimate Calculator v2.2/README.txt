Hello!
In order to run this fine peice of software you will first need to
head to the folder titled "uc2", then double click on the program titled "Ultimate Calculator V2.2"
Dont worry if your antivirus software throws a flag saying the program might be harmful, this happens
because it is packaged as a .exe file for convienence, unfortunately some malicious programs also
employ .exe

	 			-Clackk