Hello!
In order to run this fine peice of software you will first need to
download Python onto your computer. (any version made in the past 5 years will do just fine)
Alternatively you could just convert it into a text file and copy the code onto an online
Python compiler and run it thataway. Thank you!

	 			-Clackk